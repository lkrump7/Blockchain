import java.io.Serializable;

public class Transaction implements Serializable{
	
	private String ProductName;
	
	
	private double Price;
	private int quantity;
	private long timestamp;
	public long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	public Transaction()
	{
		
	}
	public Transaction(String ProductName, double price,int quantity) {
		this.ProductName=ProductName;
		Price=price;
		this.quantity=quantity;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
