
public class Edge {
	
	
	private int portNumber;
	private String host;
	public Edge() {
		
	}
	public Edge(String host, int port) {
		this.host=host;
		this.portNumber=port;
	}
	public int getPortNumber() {
		return portNumber;
	}
	public void setPortNumber(int portNumber) {
		this.portNumber = portNumber;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
}
