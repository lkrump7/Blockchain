import java.util.ArrayList;

public class Blockchain {
	
	private ArrayList<Block> chain=new ArrayList<Block>();
	
	public Blockchain(){
		
	}
	public Block newBlock() {
		int count=chain.size();
		String previousHash="";
		if(count>0) {
			previousHash=chain.get(chain.size()-1).getHash();					
		}else {
			previousHash="start";
		}
		Block block=new Block();
		block.setTimeStamp(System.currentTimeMillis());
		block.setIndex(count);
		block.setPreviousHash(previousHash);
		return block;
	}
	public ArrayList<Block> getChain() {
		return chain;
	}

	public void setChain(ArrayList<Block> chain) {
		this.chain = chain;
	}
	
	public Blockchain add(Transaction item) {
		
		if(chain.size()==0) {
			chain.add(newBlock());
		}else {
			chain.add(newBlock());
		}
		chain.get(chain.size()-1).addTransaction(item);
		return this;
	}
	
	public boolean valid() {
		for(int i=0;i<chain.size()-1;i++) {
			if(!chain.get(i).getHash().equals(chain.get(i-1).getHash())) {
				return false;
			}
			if(!chain.get(i).getHash().substring(0,4).equals("0000")) {
				return false;
			}
		}
		return true;
	}
	public Blockchain add(Block block) {
		chain.add(block);
		return this;
	}
	
	public int getSize() {
		return chain.size();
	}
}
