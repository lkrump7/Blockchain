import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.FileSystemNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class Store {

	private JFrame frame;
	private JLabel lblNewLabel;
	private JPanel panel3;
	private JPanel panel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_1_1;
	private JLabel lblNewLabel_1_1_1;
	private JTextField textField;
	private JTextField priceField;
	private JTextField nameField;
	private JTextField quantityField;
	ArrayList<Edge> edgeList=new ArrayList<Edge>();
	/**
	 * Launch the application.
	 */
	ArrayList<Transaction> transactions=new ArrayList();
	Blockchain blockChain=new Blockchain();
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Store window = new Store();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	File file=new File("data/blocks.dat");
	FileOutputStream fos;
	BufferedOutputStream bos;
	ObjectOutputStream oos;
	private static Graph graph;
	/**
	 * Create the application.
	 */
	Edge edge;
	public Store() {
		initialize();
		Random ran=new Random();

		graph.getVertices().add(this);
		List<Edge> edges=graph.getEdges();
		int port=0;
		for(Edge e:edges) {
			port=ran.nextInt(60000)+1024;
			while(e.getPortNumber()==port) {
				port=ran.nextInt(60000)+1024;
			}
		}
		edge=new Edge("localhost",port);
		graph.getEdges().add(edge);
	}
	Socket socket;
	OutputStream output;
	ObjectOutputStream ooss;
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		
		frame = 
				new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel(new GridLayout(0,2));
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JPanel panel2=new JPanel();
		lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel2.add(lblNewLabel_1);
		
		nameField = new JTextField();
		panel2.add(nameField);
		nameField.setColumns(10);
		
		JPanel panel3=new JPanel();
		
		lblNewLabel_1_1 = new JLabel("Quantity");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel3.add(lblNewLabel_1_1);
		
		quantityField = new JTextField();
		quantityField.setHorizontalAlignment(SwingConstants.CENTER);
		panel3.add(quantityField);
		quantityField.setColumns(10);
		
		JPanel panel5=new JPanel();
		
		lblNewLabel_1_1_1 = new JLabel("Price");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel5.add(lblNewLabel_1_1_1);
		
		priceField = new JTextField();
		panel5.add(priceField);
		priceField.setColumns(10);
		JLabel label=new JLabel("Add New Product"); 
		label.setHorizontalAlignment(SwingConstants.CENTER);

		JPanel panel4=new JPanel(new GridLayout(0,1));
		panel4.add(label);
		panel4.add(panel2);
		panel4.add(panel3);
		panel4.add(panel5);
		JButton button=new JButton("Add");
		
		panel.add(panel4);
		panel4.add(button);
		
		
		JPanel right=new JPanel();
		panel.add(right);
		JTextArea panel6=new JTextArea();
		panel6.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(panel6);
		scrollPane.setPreferredSize(new Dimension(100,100));
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		try {
			fos=new FileOutputStream(file,true);
			bos=new BufferedOutputStream(fos);
			oos=new ObjectOutputStream(bos);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		JButton button4=new JButton("button4");
		JButton button2=new JButton("Load Current products");
		button2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				/*File file=new File("data/Prods.txt");
				try {
					Scanner scan=new Scanner(file);
					String result="";
					while(scan.hasNext()) {
						String line=scan.nextLine();
						result+=line+"\n";
						panel6.setText(result);
						panel.paintComponents(panel.getGraphics());
						
					}
					scan.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}*/
				File file=new File("data/blocks.dat");
				try {
					FileInputStream fis=new FileInputStream(file);
					BufferedInputStream bis=new BufferedInputStream(fis);
					ObjectInputStream ois=new ObjectInputStream(bis);
					String result="";
					Object obj;
					while((obj=ois.readObject())!=null) {
						Block block=(Block) obj;
						result+=block.getTransactions().getProductName()+" "+block.getTransactions().getQuantity()+" "+block.getTransactions().getPrice()+"\n";
						panel6.setText(result);
						panel6.paintComponents(panel6.getGraphics());
					}
					ois.close();
					
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}catch(EOFException ex) {
					
				}catch (IOException e1) {
				
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				/*File file=new File("data/Prods.txt");
				try {
					FileWriter fw=new FileWriter(file, true);
					PrintWriter pw=new PrintWriter(fw);
					pw.println(nameField.getText()+" "+quantityField.getText()+" "+priceField.getText());
					pw.flush();
					
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}*/
				Random ran=new Random();
				Transaction trans=new Transaction(nameField.getText(),Double.parseDouble(priceField.getText()),Integer.parseInt(quantityField.getText()));
				trans.setTimestamp(System.currentTimeMillis());
				Block  block=new Block(trans);
				block.setTimeStamp(trans.getTimestamp());
				block.setIndex(ran.nextInt(1000));
				if(blockChain.getSize()>0) {
					block.setPreviousHash(blockChain.getChain().get(blockChain.getSize()-1).getHash());
				}else {
					block.setPreviousHash("0000");
				}
				long finishTime = System.currentTimeMillis()+60000;
				boolean found=false;
				while(System.currentTimeMillis() <= finishTime){
					
					block.makeHash();
					System.out.println(block.getHash());

					if(block.getHash().substring(0,4).equals("0000")) {
						blockChain.add(block);
						JOptionPane.showMessageDialog(panel6, "Added new Block");
						found=true;
						break;
					}
				}
				if(!found) {
					JOptionPane.showMessageDialog(panel6, "Could not compute valid block in time");
				}
				
				try {
					
					oos.reset();
					if(block!=null) {
					oos.writeObject(block);
					oos.flush();
					}
					
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		right.add(button2);
		right.add(scrollPane);
		
		JPanel panel_1 = new JPanel(new GridLayout(0,1));
		frame.getContentPane().add(panel_1, BorderLayout.WEST);
		JButton btnNewButton = new JButton("Open New Store");
		ArrayList<Store> branches=new ArrayList<Store>();
		btnNewButton.addActionListener((e)->{
			String[] args= {"branch",""+System.nanoTime()};
			
			Store branch=new Store();
			branches.add(branch);
			branch.main(args);
			
			
			
		});
		panel_1.add(btnNewButton);
	
		JButton blockButton = new JButton("Update Blockchain");
		frame.getContentPane().add(blockButton, BorderLayout.CENTER);
		
		JButton bButton = new JButton("Check Products Sync");
		frame.getContentPane().add(bButton, BorderLayout.EAST);
		
		JPanel panel_2 = new JPanel();
		frame.getContentPane().add(panel_2, BorderLayout.SOUTH);
		
		JButton connect = new JButton("Connect");
		panel_2.add(connect);
		
		JButton exit = new JButton("Exit");
		exit.addActionListener((e)->{
			try {
				oos.close();
				System.exit(0);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		
		JButton compare = new JButton("Compare Block chain");
		panel_2.add(compare);
		
		compare.addActionListener((e)->{
			try {
				ServerSocket ss=new ServerSocket(edge.getPortNumber(),10);
				Socket socket=ss.accept();
				InputStream is=socket.getInputStream();
				
				ObjectInputStream ois=new ObjectInputStream(is);
				Object obj;
				if((obj=ois.readObject())!=null) {
					Blockchain block=(Blockchain) obj;
					//validateBlockChain(block);
				}else {
					return;
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		
		panel_2.add(exit);
		connect.addActionListener((e)->{
			int edgeIndex=graph.getEdges().indexOf(edge);
			Edge edg=(Edge) graph.getEdges().get(edgeIndex-1);
			try {
				ServerSocket ss=new ServerSocket(edg.getPortNumber(),10);

				socket=ss.accept();
				output=socket.getOutputStream();
				ooss=new ObjectOutputStream(output);
				oos.writeObject(blockChain);
			} catch (UnknownHostException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		blockButton.addActionListener((e)->{
			ArrayList<Block> blocks=new ArrayList<Block>();
			for(int i=0;i<transactions.size();i++) {
				Block block=new Block(transactions.get(i));
				block.setTimeStamp(transactions.get(i).getTimestamp());
				block.setIndex(i);
				
				if(i==0) {
					block.setPreviousHash("0000");
					block.makeHash();
					blocks.add(block);
				}else {
					block.setPreviousHash(blocks.get(i-1).getHash());
					block.makeHash();
					blocks.add(block);
				}
				
			}
			blockChain.setChain(blocks);
			if(blockChain.valid()) {
				JOptionPane.showMessageDialog(panel6, "Valid");
			}
			
		});
		
		graph=new Graph<>();

	}
	public void setGraph(Graph graph) {
		this.graph=graph;
	}
	public boolean validateBlockChain(Blockchain blockchain) {
		 if(blockChain.valid()) {
			 return true;
		 }else {
			 return false;
		 }
	}
	
}
