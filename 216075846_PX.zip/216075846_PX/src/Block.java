import java.io.Serializable;
import java.security.DigestException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Hashtable;

public class Block implements Serializable {
	
	final String ALGORITHM="SHA-256";
	
	public long timeStamp;
	private int index;
	private String hash;
	private String previousHash;
	private String nonce="0000";
	private Transaction transactions=null;
	private int buffer;
	Hashtable<String, Transaction> dict=new Hashtable<String, Transaction>();
	public Block() {
		
	}
	
	public Block(Transaction trans) {
		this.transactions=trans;
	}
	public String getNonce() {
		return nonce;
	}

	public void setNonce(String nonce) {
		this.nonce = nonce;
	}

	public void setTimeStamp(long timeStamp) {
		this.timeStamp=timeStamp;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getPreviousHash() {
		return previousHash;
	}

	public void setPreviousHash(String previousHash) {
		this.previousHash = previousHash;
	}

	public long getTimeStamp() {
		return timeStamp;
	}
	
	public void makeHash() {
		MessageDigest md=null;
		String toHash=(timeStamp+index+previousHash+nonce+buffer++);

		try {
			md=MessageDigest.getInstance(ALGORITHM);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		md.update(toHash.getBytes());
		byte[] digest=md.digest();
		
		hash=byteArrayToHexString(digest);
	}
	private static String byteArrayToHexString(byte[] arrayBytes) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < arrayBytes.length; i++) {
            stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16)
                    .substring(1));
        }
        return stringBuffer.toString();
    }

	public Transaction getTransactions() {
		return transactions;
	}

	public void setTransactions(Transaction transactions) {
		this.transactions = transactions;
	}
	
	public Block addTransaction(Transaction t) {
		transactions=t;
		dict.put(String.valueOf(hashCode()), t);
		makeHash();
		
		return this;
	}
	
}
